package br.com.fiap.ejb;

public class RuntimeException extends Exception {

	public RuntimeException() {
		super();
	}

	public RuntimeException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public RuntimeException(String arg0) {
		super(arg0);
	}

	public RuntimeException(Throwable arg0) {
		super(arg0);
	}

	
}
