package br.com.fiap.ejb3.session;

public interface Calculadora {

	public long somar(long numero1, long numero2);

	public void remove();

}
