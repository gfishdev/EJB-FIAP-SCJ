package br.com.fiap.rmi;

import java.io.Serializable;

public class Item implements Serializable {
	
	//private transient String nome;
	private String nome;
	private double preco;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	
}
